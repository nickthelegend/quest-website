import HomePageContent from '@/components/HomePageContent'; // Import the new Client Component

export default function Home() {
  return <HomePageContent />; // Render the Client Component
}